const PAYSYNC_API_URL = "https://api.paysync.com.br";

const PAYSYNC_API_KEY = process.env.PAYSYNC_API_KEY;

export async function createPaySyncCardPayment(data) {

  const response = await fetch(
    `${PAYSYNC_API_URL}/v1/card-payments`,
    {
      method: "POST",

      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${PAYSYNC_API_KEY}`
      },

      body: JSON.stringify(data)
    }
  );

  const result = await response.json();

  if (!response.ok) {

    console.log("PaySync error:", result);

    throw new Error(
      result?.message || "Erro ao criar pagamento"
    );

  }

  return result;

}