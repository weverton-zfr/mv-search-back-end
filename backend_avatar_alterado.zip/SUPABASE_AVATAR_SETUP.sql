-- Rode no SQL Editor do Supabase antes de testar avatar.

alter table profiles
add column if not exists avatar_url text;

-- Crie também um bucket público chamado "avatars" em Storage > New bucket.
-- Nome: avatars
-- Public bucket: ON
